library(dplyr)
library(tidyr)
library(xtable)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) {
    stop("Usage tabularise-h44-runtimes.R <hpxData> <hdphData>")
}

hpxFile <- args[1]
hdphFile <- args[2]

hpx  <- read.table(hpxFile, header = T)
hdph <- read.table(hdphFile, header = T)

hpx  <- hpx  %>% select(totalWorkers, runtime) %>%
  mutate(variant = "CTSL", speedup = runtime[totalWorkers == 1]/runtime)

hdph <- hdph %>% select(totalWorkers, runtime) %>%
  mutate(variant = "HTSL", speedup = runtime[totalWorkers == 1]/runtime)

combined <- bind_rows(hpx,hdph)

oneDP <- function(x) {
  s = format(round(x, 1), nsmall = 1)
  gsub("\\s", "", s)
}

zeroDP <- function(x) {
  s = format(round(x, 0))
  gsub("\\s", "", s)
}

combined <- combined %>% select(totalWorkers, variant, runtime, speedup) %>%
   mutate(runtime = zeroDP(runtime), speedup = oneDP(speedup)) %>%
  gather(variable, value, (runtime:speedup)) %>%
  unite(temp, variant, variable) %>%
  spread(temp, value)


tab <- xtable(combined)
headers <- c("& \\multicolumn{2}{c}{CTSL} & \\multicolumn{2}{c}{HTSL} \\\\\n",
             "Workers & Time (s) & Speedup & Time (s) & Speedup \\\\\n")
print(tab,
      file = "fg-h44-table.tex",
      only.contents = T,
      include.rownames = F,
      include.colnames = F,
      booktabs = T,
      sanitize.text.function = function (x) { gsub("_", "\\\\_", x)},
      add.to.row = list(pos = list(0,0), command = headers),
      )
