library(dplyr)
library(ggplot2)
library(grid)

theme_set(theme_bw())

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) {
    stop("Usage plot-speedups.R <maclique-datafile> <ctsl/htsl>")
}

inputFile <- args[1]
framework <- args[2]

data <- read.table(inputFile, header = T)

scaling <- data %>%
  group_by(instance, totalWorkers) %>%
  summarise(runtimeM = mean(runtime, na.rm = T)) %>%
  mutate(speedup = runtimeM[totalWorkers == 1] / runtimeM)

maxSpeedup = max(scaling$speedup)

names <- as.list(levels(scaling$instance))
instanceNames <- split(names, c(1,2))

plots <- list()
for (n in instanceNames) {
  d <- filter(scaling, instance %in% n)
  plot = ggplot(data = d, aes(x = totalWorkers, y = speedup, linetype = instance, colour = instance)) +
    geom_line(size=1.3) +
    xlab("Workers") +
    scale_x_continuous(breaks=c(1,32,64,128,200)) +
    ylab("Relative Speedup") +
    ylim(c(-1, maxSpeedup + 5)) +
    theme(text = element_text(size=25), axis.text.y = element_text(size=18), axis.text.x = element_text(size=18), legend.key.width=unit(0.8,"cm"),aspect.ratio=1, legend.title = element_blank()) +
    guides(linetype = guide_legend(override.aes = list(size=0.8)))
  plots = list(plots, plot)
}

pdf(paste(framework, "-maxclique-speedups.pdf", sep=''))
invisible(lapply(plots, print))
dev.off()
