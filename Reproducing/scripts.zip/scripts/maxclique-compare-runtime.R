library(dplyr)
library(xtable)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3) {
    stop("Usage compare-runtime.R <ctsl-maclique-datafile> <htsl-maxclique-datafile> <graph-info>")
}

hpxFile  <- args[1]
hdphFile <- args[2]
graphInfoFile <- args[3]

hpxData  <- read.table(hpxFile, header = T)
hdphData <- read.table(hdphFile, header = T)
graphInfo <- read.table(graphInfoFile, header = T)

hpxM <- hpxData %>% group_by(instance, totalWorkers) %>% summarise(runtimeM = mean(runtime, na.rm = T)) %>%
  mutate(speedup = runtimeM[totalWorkers == 1] / runtimeM)
hpxM <- hpxM %>% select(instance, totalWorkers, runtimeM, speedup)

hdphM <- hdphData %>% group_by(instance, totalWorkers) %>% summarise(runtimeM = mean(runtime, na.rm = T)) %>%
  mutate(speedup = runtimeM[totalWorkers == 1] / runtimeM)
hdphM <- hdphM %>% select(instance, totalWorkers, runtimeM, speedup)

combined <- left_join(hpxM, hdphM, by = c("instance", "totalWorkers")) %>%
  rename(HPX = runtimeM.x, HdpH = runtimeM.y, HPXSpeedup = speedup.x, HdpHSpeedup = speedup.y)

graphInfo <- graphInfo %>% rename (instance = Graph)
combined <- left_join(combined, graphInfo, by = c("instance"))

# Choose a random sample of 5 instances
names <- as.list(levels(combined$instance))
set.seed(42) # For reproducible runs
instanceNames <- sample(names, 5)

# Output as Latex table

small <- function(x) {
  paste0("\\small{",x,"}")
}

zeroDP <- function(x) {
  format(round(x, 0), nsmall = 0)
}

twoDP <- function(x) {
  format(round(x, 2), nsmall = 2)
}


outD <- combined %>%
  mutate(inst = paste(instance, Edge.Density, sep = "/")) %>%
  filter(totalWorkers == 1 | totalWorkers == 200) %>%
  filter(instance %in% instanceNames) %>%
  arrange(totalWorkers) %>%
  ungroup () %>%
  mutate(inst = small(inst),
         HPX = small(twoDP(HPX)),
         HPXSpeedup = small(zeroDP(HPXSpeedup)),
         HdpH = small(twoDP(HdpH)),
         HdpHSpeedup = small(zeroDP(HdpHSpeedup))) %>%
  select(inst, totalWorkers, HPX, HPXSpeedup, HdpH, HdpHSpeedup)

tab <- xtable(outD)
headers <- c("& & \\multicolumn{2}{c}{\\small{CTSL}} & \\multicolumn{2}{c}{\\small{HTSL}} \\\\\n",
             "\\small{Instance/Density} & \\small{Workers} & \\small{Time (s)} & \\small{Speedup} & \\small{Time (s)} & \\small{Speedup} \\\\\n")
print(tab,
      file = "maxclique-runtime-comparison.tex",
      only.contents = T,
      include.rownames = F,
      include.colnames = F,
      booktabs = T,
      sanitize.text.function = function (x) { gsub("_", "\\\\_", x)},
      add.to.row = list(pos = list(0,0), command = headers)
      )
